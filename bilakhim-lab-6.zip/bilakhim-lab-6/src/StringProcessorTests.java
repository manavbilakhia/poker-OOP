// I affirm that I have carried out my academic endeavors with full academic honesty.
// @MB (Manav Bilakhia)

public class StringProcessorTests
{
    public static void main (String [] args)
    {
        Tester t = new Tester(true);

        testInsertAfter(t);
        testRemoveAll(t);
        testRemoveOnce(t);
        testReplaceOnce(t);
        testReplacelast(t);
        testPrepend(t);
        testAppend(t);
        // ... call more test methods here
        // ... write those method below

        t.finishTests();
    }

    public static void testInsertAfter(Tester t)
    {
        StringProcessor sp = new StringProcessor();

        t.assertEquals("inserting after the first character",
                       "alf", sp.insertAfter("af", 'a', 'l'));

        t.assertEquals("inserting a string after the first character",
                       "aloof", sp.insertAfter("af", 'a', "loo"));

        t.assertEquals("inserting in a string with more occurrences",
                       "alpha", sp.insertAfter("apha", 'a', 'l'));
    }

    public static void testRemoveAll(Tester t)
    {
        StringProcessor sp = new StringProcessor();
        t.assertEquals("removing all instances of a given character from a given string",
                "bnn", sp.removeAll("banana", 'a'));
    }
    public static void testRemoveOnce(Tester t)
    {
        StringProcessor sp = new StringProcessor();
        t.assertEquals("removing the first occurence of a given character from a given string",
                "bnana", sp.removeOnce("banana", 'a'));

        t.assertEquals("removing a particular occurrence of a given character from a given string",
                "banna", sp.removeOnce("banana", 'a', 2));
    }

    public static void testReplaceOnce(Tester t)
    {
        StringProcessor sp = new StringProcessor();
        t.assertEquals("replacing the first occurrence of a given character with a given replacement in a " +
                        "given string", "btnana", sp.replaceOnce("banana", 'a', 't'));
    }

    public static void testReplacelast(Tester t)
    {
        StringProcessor sp = new StringProcessor();
        t.assertEquals("replacing the last occurrence of a given character with a given replacement in a " +
                        "given string", "banant", sp.replaceLast("banana", 'a', 't'));
    }
    public static void testPrepend(Tester t)
    {
        StringProcessor sp = new StringProcessor();
        t.assertEquals("prepending a character to the beginning of a given string",
                "bactorub", sp.prepend("actorub", 'b'));

        t.assertEquals("prepending a string to the beginning of a given string",
                "bactorub", sp.prepend("rub", "bacto"));
    }
    public static void testAppend(Tester t)
    {
        StringProcessor sp = new StringProcessor();
        t.assertEquals("appending a character to the end of a given string",
                "bactorub", sp.append("bactoru", 'b'));

        t.assertEquals("appending a string to the end of a given string",
                "bactorub", sp.append("bacto", "rub"));
    }
}
