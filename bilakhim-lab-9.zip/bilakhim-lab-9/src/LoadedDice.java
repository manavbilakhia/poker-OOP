import java.util.Random;

/**
 * Represents a weighted dice
 */
public class LoadedDice implements Dice
{
    private int value;
    private int meanValue;

    /**
     * Initializes a weighted dice with a default mean value.
     */
    public LoadedDice()
    {
        this.meanValue = 4;
        this.roll();
    }

    /**
     * Initializes a weighted dice with a given mean value mean value.
     * @param meanValue takes the number that must frequently occur when the dice is rolled.
     */
    public LoadedDice(int meanValue)
    {
       this.meanValue = meanValue;
    }

    /**
     * Rolls the dice and sets the current value of the dice
     */
    public void roll() {
        double deviation = 0.3;
        int MAX_VALUE = 6;
        value = (int) Math.round(new Random().nextGaussian()
                * deviation + meanValue);
        if (value < 1) {
            value = 1;
        }
        if (value > MAX_VALUE) {
            value = MAX_VALUE;
        }
    }

    /**
     * Gets the current value of the dice
     * @return the current value of the dice
     */
    public int getValue()
    {
        return value;
    }

    /**
     * Returns a human-readable string representation.
     */
    public String toString()
    {
        return String.valueOf(value);
    }
}
