/**
 * This interface underlines the required methods for classes that represent a Dice
 */
public interface Dice
{
    /**
     *  Rolls the dice and sets the current value of the dice
     */
    public void roll();

    /**
     * Gets the current value of the dice
     * @return the current value of the dice
     */
    public int getValue();
}
