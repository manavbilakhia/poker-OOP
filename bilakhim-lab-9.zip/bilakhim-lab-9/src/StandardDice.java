import java.util.Random;

/**
 * Represents a standard dice
 */
public class StandardDice implements Dice
{
    private int numSides;
    private int value;

    public static final int DEFAULT_NUM_SIDES = 6;

    /**
     * Initializes a regular dice of a given number of sides.
     * @param numSides takes the number of sides
     */
    public StandardDice(int numSides)
    {
	this.numSides = numSides;
	this.value = numSides;
    }

    /**
     * Initializes a regular dice with a default number of sides.
     */
    public StandardDice()
    {
	this(DEFAULT_NUM_SIDES);
    }

    /**
     * Rolls the dice and sets the current value of the dice
     */
    public void roll()
    {
	value = new Random().nextInt(numSides) + 1;
    }

    /**
     * Gets the current value of the dice
     * @return the current value of the dice
     */
    public int getValue()
    {
	return value;
    }

    /**
     * Gets the number of sides of a dice
     * @return the number of sides of the dice
     */
    public int getNumSides()
    {
	return numSides;
    }

    /**
     * Returns a human-readable string representation.
     */
    public String toString()
    {
        return String.valueOf(this.value);
    }
    
}
