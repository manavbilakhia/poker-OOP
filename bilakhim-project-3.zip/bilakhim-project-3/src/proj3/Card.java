// I affirm that I have carried out my academic endeavors with full academic honesty.
// @MB (Manav Bilakhia)

package proj3; // do not erase. Gradescope expects this.

/**
 * This class represents a standard playing card and has functions relating to comparison of 2 cards based on their ranks
 * and their suits
 */

public class Card
{
    private final int rank;
    private final String suit;

    /**
     * Parameterized constructor of the class card.
     * @param rank An integer value assigned to a card.
     * @param suit A string value assigned to the card.
     */
    public Card(int rank, String suit)
    {
        this.rank = rank;
        this.suit = suit;
    }

    /**
     * Gets the rank of a card.
     * @return An integer value rank.
     */
    public int getRank()
    {
        return this.rank;
    }
    /**
     * Gets the suit of a card.
     * @return An string value suit.
     */
    public String getSuit()
    {
        return this.suit;
    }

    /**
     * Checks whether this and other have the same suit.
     * @param other The other card.
     * @return A boolean value, true if they have the same suit, else false.
     */
    public boolean equalsSuit (Card other)
    {
        String t1 = this.suit;
        String t2 = other.suit;
        return t1 == t2;
    }
    /**
     * Checks whether this has a lesser rank than the other.
     * @param other The other card.
     * @return A boolean value, true if this has a lesser rank, else false.
     */
    public boolean lesserThanRank(Card other)
    {
        int t1 = this.rank;
        int t2 = other.rank;
        return t1 < t2;
    }
    /**
     * Checks whether this has a greater rank than the other.
     * @param other The other card.
     * @return A boolean value. true if this has a greater rank, else false.
     */
    public boolean greaterThanRank(Card other)
    {
        int t1 = this.rank;
        int t2 = other.rank;
        return t1 > t2;
    }
    /**
     * Checks whether this and other have the same rank.
     * @param other The other card.
     * @return A boolean value, true if they have the same rank, else false.
     */
    public boolean equalsRank(Card other)
    {
        int t1 = this.rank;
        int t2 = other.rank;
        return t1 == t2;
    }

    /**
     * Returns a human readable string representation of a card with string values for the ranks.
     */
    public String toString()
    {
        String[] RANKS = {"Two","Three","Four","Five","Six","Seven","Eight","Nine","Ten","Jack","Queen","King","Ace"};

        return RANKS[this.getRank()-2] + " of " + this.getSuit();
    }
}