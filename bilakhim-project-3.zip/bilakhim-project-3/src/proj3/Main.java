// I affirm that I have carried out my academic endeavors with full academic honesty.
// @MB (Manav Bilakhia)

package proj3;

import java.util.Scanner;

/**
 * This is the main simulation of the game.
 */
public class Main
{
    public static void theGame()
    {
        final int GAMES_Played = 5;
        int score = 0;
        final int CARDS_IN_A_hand = 5;

        score = 0;
        Deck deck = new Deck();
        deck.shuffle();
        for (int i = 0; i <= GAMES_Played-1; i++)
        {
            PokerHand hand1 = new PokerHand();
            PokerHand hand2 = new PokerHand();
            for (int j = 0; j <= CARDS_IN_A_hand-1; j++)
            {
                hand1.addCard(deck.deal());
                hand2.addCard(deck.deal());
            }
            System.out.println("hand 1: " + hand1);
            System.out.println("hand 2: " + hand2);
            System.out.println("Which is the better hand? please enter positive value for hand 1, negative " +
                    "value for hand 2 and 0 for tie");
            Scanner sc = new Scanner(System.in);
            int betterHand = hand1.compareTo(hand2);
            System.out.println(betterHand);
            int userResponse = sc.nextInt();
            if ((betterHand == -1 && userResponse <= -1) || (betterHand == 1 && userResponse >= 1) ||
                    (betterHand == 0 && userResponse == 0))
            {
                System.out.println("Correct Answer");
                score++;
                System.out.println("Your current score is: " + score);
            }
            else
            {
                System.out.println("Incorrect Answer");
                System.out.println("Your final Score is: " + score);
                System.exit(0);
            }
        }
    }

    /**
     * A method to call the simulation of the game.
     * @param args Parameter to store java line commands.
     */
    public static void main(String[] args)
    {
        theGame();
    }

}