// I affirm that I have carried out my academic endeavors with full academic honesty.
// @MB (Manav Bilakhia)

package proj3; // do not erase. Gradescope expects this.

import java.util.ArrayList;

/**
 *  Represents a standard poker hand
 */
public class PokerHand {

    private final static int CARDS_IN_A_HAND = 5;
    private ArrayList<Card> contents;

    /**
     * Default constructor for class PokerHand
     */
    public PokerHand()
    {
        this.contents = new ArrayList<>();
    }

    /**
     * Parameterized constructor for class PokerHand
     * @param cardList the list ofd cards that have to be added to the hand.
     */
    public PokerHand(ArrayList<Card> cardList)
    {
        this.contents = cardList;
    }

    /**
     * Adds a single card to the hand
     * @param card the card to be added
     */
    public void addCard(Card card)
    {
        if (this.contents.size() < 5)
        {
            this.contents.add(card);
        }
    }

    /**
     * Gets the card at a particular index from the hand
     * @param i Index
     * @return A card
     */
    public Card getCard(int i)
    {
         if (i>0 && i<5)
         {
             return this.contents.get(i);
         }
         return null;
    }

    /**
     * Sorting a poker hand in descending order.
     */
    private void handSort()  //selection sort
    {
        for (int i = 0; i < CARDS_IN_A_HAND - 1; i++)
        {
            Card max = this.contents.get(i);
            int pos = i;
            for (int j = i; j < CARDS_IN_A_HAND; j++)
            {
                if (this.contents.get(j).greaterThanRank(max))
                {
                    max = this.contents.get(j);
                    pos = j;
                }
            }
            Card temp = this.contents.get(i);
            this.contents.set(i, this.contents.get(pos));
            this.contents.set(pos, temp);
        }
    }

    /**
     * Checks if the hand is a flush.
     * @return true if its a flush, else false.
     */
    private boolean checkFlush()
    {
        this.handSort();
        String handSuit = this.contents.get(0).getSuit();
        for (int i = 0; i < CARDS_IN_A_HAND; i++)
        {
            if (handSuit != this.contents.get(i).getSuit())

            {
                return false;
            }
        }
        return true;
    }

    /**
     * Compares the ranks of two cards.
     * @param other the other hand
     * @return 1 if this is greater than other. -1 if this is lesser than this. 0 if both are equal.
     */
    private int compareRanks(PokerHand other)
    {
        for (int i = 0; i < CARDS_IN_A_HAND; i++)
        {
            if (this.contents.get(i).greaterThanRank(other.contents.get(i)))
            {
               return 1;
            }
            else if(this.contents.get(i).lesserThanRank(other.contents.get(i)))
            {
                return -1;
            }
        }
        return 0;
    }

    /**\
     * Counts the pairs of a poker hand
     * @return the number of pairs in the hand
     */
    private int countPairs()
    {
        this.handSort();
        int noOfPairs = 0;
        int i = 0;
        while(i < CARDS_IN_A_HAND-1)
        {
           Card card1 = this.contents.get(i);
           Card card2 = this.contents.get(i+1);
           if(card1.equalsRank(card2))
           {
               this.contents.add(2 * noOfPairs, this.contents.remove(i));
               this.contents.add(2 * noOfPairs, this.contents.remove(i+1));
               noOfPairs = noOfPairs + 1;
               i = i+2;
           }
           else
           {
               i = i+1;
           }
        }
        return noOfPairs;
    }

    /**
     * Compares two hands
     * @param other the other hand
     * @return 1 if this is greater than other. -1 if this is lesser than this.
     */
    public int compareTo(PokerHand other)
    {
          PokerHand hand1 = this;
          PokerHand hand2 = other;
          if (hand1.checkFlush() && hand2.checkFlush())
          {
              return this.compareRanks(other);
          }
          else if(hand1.checkFlush())
          {
              return 1;
          }
          else if(hand2.checkFlush())
          {
              return -1;
          }
          else if(hand1.countPairs() == 2 && hand2.countPairs() == 2)
          {
              return this.compareRanks(other);
          }
          else if(hand1.countPairs() == 2)
          {
              return 1;
          }
          else if(hand2.countPairs() == 2)
          {
              return -1;
          }
          else if(hand1.countPairs() == 1 && hand2.countPairs() == 1)
          {
              return this.compareRanks(other);
          }
          else if(hand1.countPairs() == 1)
          {
              return 1;
          }
          else if(hand2.countPairs() == 1)
          {
              return -1;
          }
          else
          {
              return this.compareRanks(other);
          }
    }

    /**
     * returns a human readable string representation of a hand
     */
    public String toString() {
        return this.contents.toString();
    }


}