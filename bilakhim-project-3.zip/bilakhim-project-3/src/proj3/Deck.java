// I affirm that I have carried out my academic endeavors with full academic honesty.
// @MB (Manav Bilakhia)

package proj3; // do not erase. Gradescope expects this.
import java.util.*;

/**
 * This class represents a standard deck of cards and has functions related top the entire deck.
 */

public class Deck
{
    private static final int[] RANKS = {2,3,4,5,6,7,8,9,10,11,12,13,14};
    private static final String[] SUITS = {"Clubs","Diamonds","Hearts","Spades"};
    private ArrayList<Card> contents;
    private int next_to_deal = 0;
    private static final int CARDS_IN_A_DECK = 52;

    /**
     * initializes a function as in instance variable.
     */
    public Deck()
    {
        this.initializeCards();
    }

    /**
     * Creates a deck of cards.
     */
    private void initializeCards()
    {
        ArrayList<Card> cards = new ArrayList<>();
        for (int rank : RANKS)
        {
            for (String suit : SUITS)
            {
                cards.add(new Card(rank, suit));
            }
        }
        this.contents = cards;
    }

    /**
     * Shuffles the deck of cards.
     */
    public void shuffle()
    {
        int size = this.contents.size();
        Random random = new Random();
        for (int i = 0; i < size; i++)
        {
            int change = i + random.nextInt(size-i);
            swap(this.contents, i, change);
        }
    }

    /**
     * Swaps the position of 2 cards in an arraylist.
     * @param a the index of card one to be swapped
     * @param i the index of card 2 to be swapped
     * @param change the arraylist in which it must swap the cards
     */
    private void swap(ArrayList<Card> a, int i, int change)
    {
        Card helper = a.get(i);
        a.set(i, a.get(change));
        a.set(change, helper);
    }

    /**
     * this method deals a card without removing itr from the deck.
     * @return returns the card that is to be dealt from the deck
     */
    public Card deal()
    {
        Card to_be_delt = this.contents.get(next_to_deal);
        next_to_deal++;
        return to_be_delt;
    }

    /**
     * it returns the card at a given position in the deck
     */
    public Card cardAtAPosition()
    {
        return this.contents.get(next_to_deal);
    }

    /**
     * returns the current size of the given deck.
     */
    public int size()
    {
        return CARDS_IN_A_DECK - next_to_deal;
    }

    /**
     * gathers the pre-existing deck of cards to play again.
     */
    public void gather()
    {
        next_to_deal = 0;
    }

    /**
     * Returns a human-readable string representation.
     */
    public String toString()
    {
        return this.contents.toString();
    }

}