import java.util.ArrayList;
import java.util.Arrays;

/**
 * @author Manav Bilakhia (MB)
 */

public class TicTacToeBoardTests
		/**
		 * calling all methods to test
		 */
{
    public static void main(String [] args)
    {
	Tester suite = new Tester();

	testGetWinner(suite);

	suite.finishTests();
    }

	/**
	 * test cases
	 * @param suite testing parameter
	 */
    public static void testGetWinner(Tester suite)
    {
    	System.out.println("TEST 1"); // line 123,141
	    String[] strs = 	{   "XOX",
				                "XOO",
				                "XXO"};
	    ArrayList<String> rows = new ArrayList<>(Arrays.asList(strs));
	    TicTacToeBoard aBoard = new TicTacToeBoard(rows);
	    suite.testSection("Testing getWinner()");
	    suite.assertEquals(aBoard + "Three Xs in a row vertically",
			   'X',
			   aBoard.getWinner());


//----------------------------------------------------------------------------------------------------------------------

		System.out.println("TEST 2"); // line 121, 143
		String[] strs11 = 	{   "XOX",
			                	"OOO",
								"XXO"};
		ArrayList<String> rows11 = new ArrayList<>(Arrays.asList(strs11));
		aBoard = new TicTacToeBoard(rows11);
		suite.testSection("Testing getWinner()");
		suite.assertEquals(aBoard + "Three Os in a row horizontally",
				'O',
				aBoard.getWinner());

//----------------------------------------------------------------------------------------------------------------------

		System.out.println("TEST 3"); // line  130, 143
		String[] strs16 = 	{   "XOO",
								"OOX",
								"OXX"};
		ArrayList<String> rows16 = new ArrayList<>(Arrays.asList(strs16));
		aBoard = new TicTacToeBoard(rows16);
		suite.testSection("Testing getWinner()");
		suite.assertEquals(aBoard + "Three Os in a row diagonally",
				'O',
				aBoard.getWinner());

//----------------------------------------------------------------------------------------------------------------------

		System.out.println("TEST 4"); // line 145
		aBoard.clearCell(0, 2);
		suite.assertEquals(aBoard + "Incomplete board, no winner yet",
				' ',
				aBoard.getWinner());

//----------------------------------------------------------------------------------------------------------------------
		System.out.println("TEST 5"); // line 128, 141
		String[] strs5 = 	{   "XOO",
				"XXO",
				"OXX"};
		ArrayList<String> rows5 = new ArrayList<>(Arrays.asList(strs5));
		aBoard = new TicTacToeBoard(rows5);
		suite.testSection("Testing getWinner()");
		suite.assertEquals(aBoard + "Three Os in a row diagonally",
				'X',
				aBoard.getWinner());

	}
}

