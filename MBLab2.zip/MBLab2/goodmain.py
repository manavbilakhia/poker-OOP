def main():
    """
    This function creates a board from the input text file. This function also underlines the entire flow of this
    project.
    :return: list of elements on the input file.
    """
    input_file = 'input.txt'
    file = open(input_file)
    board = file.read().split('\n')
    file.close()
    print_board(board)
    winner = check_winner(board)

    if winner != '':
        print("  ")
        print(winner + ' WINS!!!!')
    else:
        print("  ")
        print("TIE GAME!!!!")
    return board


def print_board(board):
    """
    This function prints the board in the desired format.
    :param board: list of elements on the input file.
    """
    num_rows = len(board)
    num_cols = len(board[0])

    for row_num, row in enumerate(board):
        row_str = ''

        for col_num, marker in enumerate(row):
            row_str += marker

            if col_num < num_cols - 1:
                row_str += ' | '
        print(row_str)

        if row_num < num_rows - 1:
            print('---------')


def check_winner(board):
    """
    This function finds out who is the winner by checking the winning combination.
    :param board: list of elements on the input file.
    :return: string containing the winner or a blank string if its a tie game.
    """
    for row_num, row in enumerate(board):
        if row_all_same(board, row_num):
            winner = board[row_num][0]
            return winner

    for col in columns(board):
        if column_or_diagonal_all_same(col):
            winner = col[0]
            return winner

    if column_or_diagonal_all_same(get_back_slash(board)):
        winner = board[0][0]
        return winner

    if column_or_diagonal_all_same(get_forward_slash(board)):
        winner = board[2][0]
        return winner

    else:
        winner = ''
        return winner


def row_all_same(board, row):
    """
    This function checks if all 3 elements of the given list are the same.
    :param board: list of elements on the input file.
    :param row: list of elements in one row.
    :return: true if all 3 elements in the row are same, false if not.
    """
    return board[row][0] == board[row][1] == board[row][2]


def column_or_diagonal_all_same(input_list):
    """
    This function checks if all 3 elements of the given list are the same.
    :param input_list: list of elements in a diagonal or column as per what is passed during the function call.
    :return: true if all 3 elements in the given list are same, false if not.
    """
    return input_list[0] == input_list[1] == input_list[2]


def get_back_slash(board):
    """
    This function checks if all 3 elements of the back slash diagonal are the same.
    :param board: list of elements on the input file.
    :return: element in the backward diagonal.
    """
    return [board[i][i] for i in range(len(board))]


def get_forward_slash(board):
    """
    This function checks if all 3 elements of the forward slash diagonal are the same.
    :param board: list of elements on the input file.
    :return: element in the forward diagonal.
    """
    return [board[len(board) - i - 1][i] for i in range(len(board))]


def columns(board):
    """
    This function creates a list of all elements in a column.
    :param board: list of elements on the input file.
    :return: list of elements in a column.
    """
    num_cols = len(board[0])
    num_rows = len(board)
    Columns = []

    for i in range(num_cols):
        col_str = ''
        for j in range(num_rows):
            col_str += board[j][i]
        Columns.append(col_str)
    return Columns


if __name__ == '__main__':
    main()
