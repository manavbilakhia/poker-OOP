# I affirm that I have carried out my academic endeavors with full academic honesty.
# @MB (Manav Bilakhia)

import card as c
import random

MAX_PIPS = 6


class Deck:
    """
    Represents a deck of cards.
    """

    def __init__(self):
        """
        Initializes the Deck with 52 cards.
        """
        self.__contents = []
        suits_in_a_deck = ["♥", "♣", "♠", "♦"]
        ranks_in_a_suit = [2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14]  # 11 = = Jack, 12 = Queen, 13 = King, 14 = Ace
        for suit in suits_in_a_deck:
            for rank in ranks_in_a_suit:
                card = c.Card(rank, suit)
                self.__contents.append(card)

    def shuffle_deck(self):
        """
        Shuffles the cards in this deck.
        """
        random.shuffle(self.__contents)

    def deal(self):
        """Removes and returns a card from the deck.
        """
        return self.__contents.pop(-1)

    def __str__(self):
        """
        Returns a human-readable string representation.
        """
        return str(self.__contents)
