# I affirm that I have carried out my academic endeavors with full academic honesty.
# @MB (Manav Bilakhia)

import test_suite


class Card:
    """
    Represents a standard playing card.
    """
    def __init__(self, rank, suit):
        self.__rank = rank
        self.__suit = suit

    def __get_rank(self):
        """
        Gets the rank of the card
        :return: the rank
        """
        return self.__rank

    def get_suit(self):
        """
        Gets the suit ofd a card
        :return: the suit
        """
        return self.__suit

    def __eq__(self, other):
        """
        Checks whether self and other have the same rank and suit.
        :return: boolean
        """
        t1 = self.__rank
        t2 = other.__rank
        return t1 == t2

    def __repr__(self):
        """
        Returns a human-readable string representation.
        """
        return str(self.__get_rank()) + " of " + str(self.get_suit())

    def __lt__(self, other):
        """
        Compares this card to other, first by rank
        :return:  boolean
        """
        t1 = self.__rank
        t2 = other.__rank
        return t1 < t2

    def test_get_rank(self):
        """
        Calling a private method for testing
        """
        return self.__get_rank()


if __name__ == '__main__':
    card = Card(10, "♦")
    suite = test_suite.TestSuite()
    suite.assert_equals("testing the get suite method", "♦", card.get_suit())
    suite.assert_equals("testing the get rank method", 10, card.test_get_rank())
    suite.print_summary()
