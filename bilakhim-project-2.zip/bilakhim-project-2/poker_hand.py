# I affirm that I have carried out my academic endeavors with full academic honesty.
# @MB (Manav Bilakhia)

import card as c
import test_suite

CARDS_IN_HAND = 5


class PokerHand:
    """
    Represents a hand of playing cards
    """

    def __init__(self):
        """
        Initializes a list of cards
        """
        self.__contents = []

    def add_card(self, card):
        """
        Adds a card to the hand
        :param card: Card
        """
        self.__contents.append(card)

    def __str__(self):
        """
        Returns a human-readable string representation.
        """
        return str(self.__contents)

    def __sort(self):
        """
        Sorts the cards in ascending order.
        """
        self.__contents.sort()

    def __check_flush(self):
        """
        Checks if the given hand is a flush.
        :return: False if suit of all cards in a hand are not equal. If not, returns True.
        """
        self.__contents.sort(reverse=True)
        hand_suit = self.__contents[0].get_suit()
        for i in range(CARDS_IN_HAND):
            if hand_suit != self.__contents[i].get_suit():
                return False
        return True

    def __compare_ranks(self, other):
        """
        Compares the ranks of cards in two different hands.
        :param other: For hand 2
        :return: The name of the winner hand or tie
        """
        for i in range(CARDS_IN_HAND):
            if self.__contents[i] > other.__contents[i]:
                return "hand 1"
            elif self.__contents[i] < other.__contents[i]:
                return "hand 2"
        return "tie"

    def __count_pairs(self):
        """
        Counts the number of pairs in a given hand.
        :return: Integer of number of pairs in a given hand.
        """
        self.__contents.sort(reverse=True)
        no_of_pairs = 0
        i = 0
        while i < CARDS_IN_HAND - 1:
            card1 = self.__contents[i]
            card2 = self.__contents[i + 1]
            if card1 == card2:
                self.__contents.insert(2 * no_of_pairs, self.__contents.pop(i))
                self.__contents.insert(2 * no_of_pairs, self.__contents.pop(i + 1))
                no_of_pairs = no_of_pairs + 1
                i = i + 2
            else:
                i = i + 1
        return no_of_pairs

    def compare_to(self, other):
        """
        Compares 2 hands
        :param other: For second hand
        :return: The name of the winner hand
        """
        hand1 = self
        hand2 = other
        if hand1.__check_flush() and hand2.__check_flush():
            return self.__compare_ranks(other)
        elif hand1.__check_flush():
            return "hand 1"
        elif hand2.__check_flush():
            return "hand 2"
        elif hand1.__count_pairs() and hand2.__count_pairs() == 2:
            return self.__compare_ranks(other)
        elif hand1.__count_pairs() == 2:
            return "hand 1"
        elif hand2.__count_pairs() == 2:
            return "hand 2"
        elif hand1.__count_pairs() and hand2.__count_pairs() == 1:
            return self.__compare_ranks(other)
        elif hand1.__count_pairs() == 1:
            return "hand 1"
        elif hand2.__count_pairs() == 1:
            return "hand 2"
        else:
            return self.__compare_ranks(other)


if __name__ == '__main__':
    hand1 = PokerHand()
    hand1.add_card(c.Card(14, "♦"))
    hand1.add_card(c.Card(1, "♦"))
    hand1.add_card(c.Card(13, "♦"))
    hand1.add_card(c.Card(2, "♦"))
    hand1.add_card(c.Card(12, "♦"))

    hand2 = PokerHand()
    hand2.add_card(c.Card(3, "♦"))
    hand2.add_card(c.Card(11, "♦"))
    hand2.add_card(c.Card(4, "♦"))
    hand2.add_card(c.Card(10, "♦"))
    hand2.add_card(c.Card(5, "♦"))

    hand3 = PokerHand()
    hand3.add_card(c.Card(6, "♦"))
    hand3.add_card(c.Card(6, "♣"))
    hand3.add_card(c.Card(13, "♣"))
    hand3.add_card(c.Card(13, "♦"))
    hand3.add_card(c.Card(5, "♦"))

    hand4 = PokerHand()
    hand4.add_card(c.Card(14, "♠"))
    hand4.add_card(c.Card(14, "♣"))
    hand4.add_card(c.Card(6, "♥"))
    hand4.add_card(c.Card(7, "♥"))
    hand4.add_card(c.Card(7, "♣"))

    hand5 = PokerHand()
    hand5.add_card(c.Card(10, "♣"))
    hand5.add_card(c.Card(13, "♥"))
    hand5.add_card(c.Card(6, "♣"))
    hand5.add_card(c.Card(8, "♦"))
    hand5.add_card(c.Card(8, "♣"))

    hand6 = PokerHand()
    hand6.add_card(c.Card(9, "♣"))
    hand6.add_card(c.Card(9, "♦"))
    hand6.add_card(c.Card(4, "♥"))
    hand6.add_card(c.Card(8, "♥"))
    hand6.add_card(c.Card(14, "♣"))

    hand7 = PokerHand()
    hand7.add_card(c.Card(13, "♦"))
    hand7.add_card(c.Card(4, "♠"))
    hand7.add_card(c.Card(6, "♦"))
    hand7.add_card(c.Card(7, "♥"))
    hand7.add_card(c.Card(10, "♠"))

    hand8 = PokerHand()
    hand8.add_card(c.Card(10, "♥"))
    hand8.add_card(c.Card(2, "♦"))
    hand8.add_card(c.Card(12, "♥"))
    hand8.add_card(c.Card(4, "♦"))
    hand8.add_card(c.Card(5, "♠"))

    hand9 = PokerHand()
    hand9.add_card(c.Card(10, "♦"))
    hand9.add_card(c.Card(2, "♥"))
    hand9.add_card(c.Card(12, "♦"))
    hand9.add_card(c.Card(4, "♥"))
    hand9.add_card(c.Card(5, "♣"))

    hand10 = PokerHand()
    hand10.add_card(c.Card(5, "♥"))
    hand10.add_card(c.Card(7, "♣"))
    hand10.add_card(c.Card(12, "♦"))
    hand10.add_card(c.Card(12, "♠"))
    hand10.add_card(c.Card(9, "♠"))

    hand11 = PokerHand()
    hand11.add_card(c.Card(3, "♥"))
    hand11.add_card(c.Card(11, "♦"))
    hand11.add_card(c.Card(10, "♣"))
    hand11.add_card(c.Card(13, "♥"))
    hand11.add_card(c.Card(11, "♠"))

    hand12 = PokerHand()
    hand12.add_card(c.Card(10, "♣"))
    hand12.add_card(c.Card(13, "♥"))
    hand12.add_card(c.Card(6, "♣"))
    hand12.add_card(c.Card(8, "♦"))
    hand12.add_card(c.Card(8, "♣"))

    hand13 = PokerHand()
    hand13.add_card(c.Card(3, "♣"))
    hand13.add_card(c.Card(3, "♦"))
    hand13.add_card(c.Card(4, "♥"))
    hand13.add_card(c.Card(8, "♥"))
    hand13.add_card(c.Card(14, "♣"))

    hand14 = PokerHand()
    hand14.add_card(c.Card(12, "♠"))
    hand14.add_card(c.Card(3, "♣"))
    hand14.add_card(c.Card(12, "♥"))
    hand14.add_card(c.Card(13, "♣"))
    hand14.add_card(c.Card(10, "♥"))

    hand15 = PokerHand()
    hand15.add_card(c.Card(4, "♠"))
    hand15.add_card(c.Card(8, "♥"))
    hand15.add_card(c.Card(8, "♣"))
    hand15.add_card(c.Card(2, "♦"))
    hand15.add_card(c.Card(14, "♥"))

    suite = test_suite.TestSuite()
    print("TEST 1")
    print(hand1)
    print(hand2)
    suite.assert_equals("testing when both hands are flush (hand 1 and hand 2)", "hand 1", hand1.compare_to(hand2))

    print("TEST 2")
    print(hand1)
    print(hand8)
    suite.assert_equals("testing when one hand is a flush other is not (hand 1 and hand 8)", "hand 1",
                        hand1.compare_to(hand8))

    print("TEST 3")
    print(hand1)
    print(hand4)
    suite.assert_equals("testing when one hand is a flush other is a 2 pair (hand 1 and hand 4)", "hand 1",
                        hand1.compare_to(hand4))

    print("TEST 4")
    print(hand1)
    print(hand13)
    suite.assert_equals("testing when one hand is a flush other is a pair (hand 1 and hand 13)", "hand 1",
                        hand1.compare_to(hand13))

    print("TEST 5")
    print(hand3)
    print(hand4)
    suite.assert_equals("testing when both hands are 2 pairs (hand 3 and hand 4)", "hand 2", hand3.compare_to(hand4))

    print("TEST 6")
    print(hand3)
    print(hand7)
    suite.assert_equals("testing when one hand is a 2pair other is not (hand 3 and hand 7)", "hand 1",
                        hand3.compare_to(hand7))

    print("TEST 7")
    print(hand5)
    print(hand6)
    suite.assert_equals("testing when both hands are pairs (hand 5 and hand 6)", "hand 2", hand5.compare_to(hand6))

    print("TEST 8")
    print(hand5)
    print(hand3)
    suite.assert_equals("testing when one hand is a pair and other is a 2pair (hand 5 and hand 3)", "hand 2",
                        hand5.compare_to(hand3))

    print("TEST 9")
    print(hand10)
    print(hand8)
    suite.assert_equals("testing when one hand is a pair other is a highcard (hand 10 and hand 8)", "hand 1",
                        hand10.compare_to(hand8))

    print("TEST 10")
    print(hand7)
    print(hand8)
    suite.assert_equals("testing when both hands are highcards (hand 7 and hand 8)", "hand 1", hand7.compare_to(hand8))

    print("TEST 11")
    print(hand8)
    print(hand9)
    suite.assert_equals("testing when both hands are a tie (hand 8 and hand 9)", "tie", hand8.compare_to(hand9))

    print("TEST 12")
    print(hand10)
    print(hand11)
    suite.assert_equals("testing when both hands are a pairs (bug test) (hand 10 and hand 11)", "hand 1",
                        hand10.compare_to(hand11))

    print("TEST 13")
    print(hand12)
    print(hand13)
    suite.assert_equals("testing when both hands are a pairs (bug test) (hand 12 and hand 13)", "hand 1",
                        hand12.compare_to(hand13))

    print("TEST 14")
    print(hand14)
    print(hand15)
    suite.assert_equals("testing when both hands are a pairs (bug test) (hand 14 and hand 15)", "hand 1",
                        hand14.compare_to(hand15))

    suite.print_summary()
