# I affirm that I have carried out my academic endeavors with full academic honesty.
# @MB (Manav Bilakhia)

import deck as d
import poker_hand as ph

CARDS_IN_HAND = 5
GAME_PLAYED = 5


def the_game():
    """
    The main simulation of the game
    :return: A blank string just to terminate the process.
    """
    score = 0
    deck = d.Deck()
    deck.shuffle_deck()
    for i in range(GAME_PLAYED):
        hand1 = ph.PokerHand()
        hand2 = ph.PokerHand()
        for j in range(CARDS_IN_HAND):
            hand1.add_card(deck.deal())
            hand2.add_card(deck.deal())

        print("hand 1: " + str(hand1))
        print("hand 2: " + str(hand2))
        user_response = input(
            "Which is a better hand, 'hand 1' / 'hand 2' / 'tie'? Please enter one of the three given options in the "
            "exact same way. ")
        if hand1.compare_to(hand2) == user_response:

            print("correct answer")
            score = score + 1
            print("your current score = " + str(score))
        else:
            print("your final score is " + str(score))
            return score


if __name__ == '__main__':
    the_game()
