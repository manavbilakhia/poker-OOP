# I affirm that I have carried out my academic endeavors with full academic honesty.
# @MB (Manav Bilakhia)

import dice as d


def main():
    """
    Runs the main game. Code stops as soon as one of the values is double of the other value.
    :return: empty string. Just to stop a code as soon as a double value is found.
    """
    i = 0
    d6 = d.Dice()
    d12 = d.Dice(12)
    input("Press return to start the game!")
    while i < 1:
        d6.roll()
        d12.roll()
        a = d6.get_value()
        b = d12.get_value()
        print("d6: " + str(a))
        print("d12: " + str(b))
        if a == 2 * b or b == 2 * a:
            print("you win!!!!!")
            return ""
        else:
            print("Try again")
            input("Press return to continue...")


if __name__ == '__main__':
    main()
