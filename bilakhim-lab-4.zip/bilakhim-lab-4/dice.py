# I affirm that I have carried out my academic endeavors with full academic honesty.
# @MB (Manav Bilakhia)

import random
import test_suite


class Dice:
    """
    Represents a standard dice
    """

    def __init__(self, side=6):
        """
        initializes by default six sided dice unless specified otherwise and the current value of the dice
        :param side: takes number of sides
        """
        self.__side = side
        self.roll()

    def roll(self):
        """
        Rolls the dice and sets the current value of the dice
        """
#        print(random.randint(1, self.__side + 1))
        self.__value = random.randint(1, self.__side)

    def get_value(self):
        """
        Gets the current value of the dice
        :return: the current value of the dice
        """
#        print(self.__value)
        return self.__value


if __name__ == '__main__':
    """
    Testing
    """
    dice1 = Dice()
    dice1.roll()
    dice1.get_value()
    dice1_range = [1, 2, 3, 4, 5, 6]
    suite = test_suite.TestSuite()
    suite.assert_equals("Testing the get value method for a D6. Current value of the dice = " + str(dice1.get_value()),
                        True, dice1.get_value() in dice1_range)
    dice2 = Dice(12)
    dice2.roll()
    dice2_range = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12]
    dice2.get_value()
    suite.assert_equals("Testing the get value method for a D12. Current value of the dice = " + str(dice2.get_value()),
                        True, dice2.get_value() in dice2_range)
