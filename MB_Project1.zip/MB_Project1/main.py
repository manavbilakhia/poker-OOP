# I affirm that I have carried out my academic endeavors with full academic honesty.
# @MB (Manav Bilakhia)

import random

deck = []
hand = []
pair = 0
flush = 0
high_card = 0
double_pair = 0
p = 0
print("{:<15} {:<1} {:<10} {:<1} {:<10} {:<1} {:<10} {:<1} {:<10}"
      .format('# of hands', 'pairs', '%', '2 pairs', '%', 'flushes', '%', 'high card', '%'))


def create_deck():
    suits = ["♥", "♣", "♠", "♦"]
    values = {"2": 2, "3": 3, "4": 4, "5": 5, "6": 6, "7": 7, "8": 8, "9": 9, "T": 10, "J": 11, "Q": 12, "K": 13,
              "A": 14}
    spaces = [" of "]
    for name in values:
        for suit in suits:
            for space in spaces:
                deck.append(name + space + suit)


#    print(deck)


def shuffle_deck():
    random.shuffle(deck)
    #    print(deck)
    return deck


def create_hand():
    global deck
    global p
    global pair
    global flush
    global high_card
    global double_pair
    for l in range(10):
        p = p + 1000
#        print(p)
        for j in range(p):
            create_deck()
            shuffle_deck()
            for k in range(10):
                for l in range(5):
                    hand.append(random.choice(deck))
                    set1 = set(deck)
                    set2 = set(hand)
                    deck = list(set1 - set2)
#                print(hand)
                check_card()
                hand.clear()
#           print(deck)
        calculation_formatting_printing()
        pair = 0
        flush = 0
        double_pair = 0
        high_card = 0



def check_card():
    global pair
    global flush
    global high_card
    global double_pair
    hand.sort()
    if hand[0][-1] == hand[1][-1] == hand[2][-1] == hand[3][-1] == hand[4][-1]:
        flush = flush + 1
    # for double pair
    elif ((hand[0][0] == hand[1][0] and hand[2][0] == hand[3][0]) or (hand[0][0] == hand[1][0] and hand[3][0] == hand[4][0])
          or (hand[1][0] == hand[2][0] and hand[3][0] == hand[4][0])):
        double_pair = double_pair + 1
   # for pair

    elif hand[0][0] == hand[1][0] or hand[1][0] == hand[2][0] or hand[2][0] == hand[3][0] or hand[3][0] == hand[4][0]:
        pair = pair + 1

    # every other combination is high card
    else:
        high_card = high_card + 1


def calculation_formatting_printing():
    global pair
    global flush
    global high_card
    global double_pair
    global p
    percent_flush = (float(flush) / p) * 10
    percent_pair = (float(pair) / p) * 10
    percent_double_pair = (float(double_pair) / p) * 10
    percent_high_card = (float(high_card) / p) * 10
# ----------------------------------------------------------------------------------------------------------------------

    # code for formatting all final values as per desired output
#    pair = '{:0>5}'.format(pair)
    percent_pair = '{:0>5}'.format("{:.2f}".format(percent_pair))
#    double_pair = '{:0>5}'.format(double_pair)
    percent_double_pair = '{:0>5}'.format("{:.2f}".format(percent_double_pair))
#    flush = '{:0>5}'.format(flush)
    percent_flush = '{:0>5}'.format("{:.2f}".format(percent_flush))
 #   high_card = '{:0>5}'.format(high_card)
    percent_high_card = "{:.2f}".format(percent_high_card)
# ----------------------------------------------------------------------------------------------------------------------

    # printing each value
    print("{:<12} {:8} {:7} {:10} {:7} {:10} {:9} {:10} {:1}"
          .format("{:,}".format(p*10), pair, percent_pair, double_pair, percent_double_pair, flush, percent_flush, high_card,
                  percent_high_card))




create_hand()
