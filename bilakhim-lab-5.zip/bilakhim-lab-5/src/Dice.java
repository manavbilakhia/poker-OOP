// I affirm that I have carried out my academic endeavors with full academic honesty.
// @MB (Manav Bilakhia)

import java.util.Random;
/**
 * Represents a standard dice
 */
public class Dice
{
    private final int side;
    private int value;

    /**
     * Initializes a regular dice of a given number of sides.
     * @param side takes the number of sides
     */
    public Dice(int side)
    {
        this.side = side;
        this.setRoll();
    }
    /**
     * Rolls the dice and sets the current value of the dice
     */
    public  void setRoll()
    {
        Random rand = new Random();
        int j = rand.nextInt(this.side);
        this.value = j+1;
    }
    /**
     * Gets the current value of the dice
     * @return the current value of the dice
     */
    public int getValue()
    {
        return this.value;
    }

    /**
     * Testing this module
     * @param args for command line parameters
     */
    public static void main(String[] args)
    {
        Dice d6 = new Dice(6);
        d6.setRoll();
        System.out.println(d6.getValue());
    }

}
