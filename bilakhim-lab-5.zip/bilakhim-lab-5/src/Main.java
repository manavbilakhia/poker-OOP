// I affirm that I have carried out my academic endeavors with full academic honesty.
// @MB (Manav Bilakhia)

import java.util.Scanner;
public class Main
{
    /**
     * Runs the main game. Code stops as soon as one of the values is double of the other value.
     * @param args For command line parameters.
     */
    public static void main(String[] args)
    {
        Dice d6 = new Dice(6);
        Dice d12 = new Dice(12);
        boolean winnerFound = false;
        while(! winnerFound)
        {
            d6.setRoll();
            d12.setRoll();
            int a = d6.getValue();
            int b = d12.getValue();
            System.out.println("D6: " + a);
            System.out.println("D12: "+b);
            if (a == 2 * b || b == 2 * a)
            {
                System.out.println("You win!!!");
                winnerFound = true;
            }
            else
            {
                Scanner sc = new Scanner(System.in);
                System.out.print("Press enter to try again");
                String line = sc.nextLine();
            }
        }
    }
}

