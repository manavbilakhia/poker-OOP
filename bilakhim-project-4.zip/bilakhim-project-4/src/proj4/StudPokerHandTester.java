package proj4;

import java.util.ArrayList;

/**
 * Testing module for class StudPokerHand.
 */
public class StudPokerHandTester
{
    /**
     * Main calls methods which have the tests.
     */
    public static void main(String[] args) {
        Testing t = new Testing();
        t.startTests();
        t.testSection("Class PokerHand");
        testMethodsOfClassStudPokerHand(t);
        t.finishTests();
    }
    /**
     * Testing methods of class StudPokerHand.
     * @param t Testing parameter.
     */
    public static void testMethodsOfClassStudPokerHand(Testing t)
    {
        Card c3 = new Card("Three","Clubs");
        Card c13 = new Card("King", "Clubs");
        Card c14 = new Card("Ace","Clubs");
        Card h3 = new Card("Three","Hearts");
        Card h4 = new Card("Four","Hearts");
        Card h12 = new Card("Queen","Hearts");
        Card h14 = new Card("Ace","Hearts");
        Card s4 = new Card("Four", "Spades");
        Card s5 = new Card("Five", "Spades");
        Card s9 = new Card("Nine", "Spades");
        Card s11 = new Card("Jack", "Spades");
        Card s12 = new Card("Queen", "Spades");
        Card s14 = new Card("Ace", "Spades");
        Card d2 = new Card("Two","Diamonds");
        Card d3 = new Card("Three","Diamonds");
        Card d4 = new Card("Four","Diamonds");
        Card d5 = new Card("Five","Diamonds");
        Card d9 = new Card("Nine", "Diamonds");
        Card d10 = new Card("Ten", "Diamonds");
        Card d11 = new Card("Jack", "Diamonds");
        Card d12 = new Card("Queen","Diamonds");
        Card d13 = new Card("King", "Diamonds");
        Card d14 = new Card("Ace", "Diamonds");

        CommunityCardSet set1 = new CommunityCardSet();
        set1.addCard(d11);
        set1.addCard(d9);
        set1.addCard(d13);
        set1.addCard(s12);
        set1.addCard(s14);
        ArrayList<Card> player1 = new ArrayList<>();    //flush
        player1.add(d12);
        player1.add(d2);
        ArrayList<Card> player2 = new ArrayList<>();    //flush
        player2.add(d3);
        player2.add(d5);
        ArrayList<Card> player3 = new ArrayList<>();    //2pair
        player3.add(h12);
        player3.add(c14);
        ArrayList<Card> player4 = new ArrayList<>();    //2 pair   
        player4.add(s9);
        player4.add(c13);
        ArrayList<Card> player5 = new ArrayList<>();    //pair
        player5.add(s11);
        player5.add(c3);
        ArrayList<Card> player6 = new ArrayList<>();    //pair
        player6.add(d14);
        player6.add(s4);
        ArrayList<Card> player7 = new ArrayList<>();    //hc
        player7.add(h3);
        player7.add(h4);
        ArrayList<Card> player8 = new ArrayList<>();    //hc
        player8.add(s5);
        player8.add(d10);
        ArrayList<Card> player9 = new ArrayList<>();    // for pair tie
        player9.add(h14);
        player9.add(d4);
        StudPokerHand hand1 = new StudPokerHand(set1, player1);
        StudPokerHand hand2 = new StudPokerHand(set1, player2);
        StudPokerHand hand3 = new StudPokerHand(set1, player3);
        StudPokerHand hand4 = new StudPokerHand(set1, player4);
        StudPokerHand hand5 = new StudPokerHand(set1, player5);
        StudPokerHand hand6 = new StudPokerHand(set1, player6);
        StudPokerHand hand7 = new StudPokerHand(set1, player7);
        StudPokerHand hand8 = new StudPokerHand(set1, player8);
        StudPokerHand hand9 = new StudPokerHand(set1, player9);
        t.assertEquals("testing when both hands are flush (hand 1 and hand 2)",
                1, hand1.compareTo(hand2));              //1
        t.assertEquals("testing when one hand is a flush other is is a 2 pair (hand 1 and hand 3)",
                1, hand1.compareTo(hand3));              //2
        t.assertEquals("testing when one hand is a flush other is a pair (hand 1 and hand 5)",
                1, hand1.compareTo(hand5));            //3
        t.assertEquals("testing when one hand is a flush other is a highcard (hand 1 and hand 7)",
                1, hand1.compareTo(hand7));                  //4
        t.assertEquals("testing when both hands are 2 pairs (hand 4 and hand 3)",
                -1, hand4.compareTo(hand3));                //5
        t.assertEquals("testing when one hand is a 2pair other is pair (hand 3 and hand 6)",
                1, hand3.compareTo(hand6));                   //6
        t.assertEquals("testing when one hand is a 2pair other is a highcard (hand 3 and hand 8)",
                1, hand3.compareTo(hand8));                 //7
        t.assertEquals("testing when one hand is a pair and other is a pair (hand 5 and hand 6)",
                -1, hand5.compareTo(hand6));                   //8
        t.assertEquals("testing when one hand is a pair and other is a highcard (hand 6 and hand 7)",
                1, hand6.compareTo(hand7));                   //9
        t.assertEquals("testing when both hands are highcards (hand 7 and hand 8)",
                -1, hand7.compareTo(hand8));                         //10
        t.assertEquals("testing when both hands tie (pairs) (hand 6 and hand 9)",
                0, hand6.compareTo(hand9));                           //11
    }
}
