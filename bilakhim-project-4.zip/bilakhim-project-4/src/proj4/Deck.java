package proj4; // do not erase. Gradescope expects this.
import java.util.*;

/**
 * This class represents a standard deck of cards and has functions related top the entire deck.
 */

public class Deck
{
    private static final int[] RANKS = {2,3,4,5,6,7,8,9,10,11,12,13,14};
    private static final int[] SUITS = {0,1,2,3};
    private ArrayList<Card> contents;
    private int next_to_deal = 0;
    private static final int CARDS_IN_A_DECK = 52;

    /**
     * Initializes a function as in instance variable.
     */
    public Deck()
    {
        this.initializeCards();
    }

    /**
     * Creates a deck of cards.
     */
    private void initializeCards()
    {
        ArrayList<Card> cards = new ArrayList<>();
        for (int rank : RANKS)
        {
            for (int suit : SUITS)
            {
                cards.add(new Card(rank, suit));
            }
        }
        this.contents = cards;
    }

    /**
     * Shuffles the deck of cards. If cards have been dealt from the deck then the function shuffles the remaining cards
     * only.
     */
    public void shuffle()
    {
        int size = this.contents.size();
        Random random = new Random();
        for (int i = next_to_deal; i < size; i++)
        {
            int change = i + random.nextInt(size-i);
            swap(this.contents, i, change);
        }
    }

    /**
     * Swaps the position of 2 cards in an arraylist.
     * @param a the index of card one to be swapped
     * @param i the index of card 2 to be swapped
     * @param change the arraylist in which it must swap the cards
     */
    private void swap(ArrayList<Card> a, int i, int change)
    {
        Card helper = a.get(i);
        a.set(i, a.get(change));
        a.set(change, helper);
    }

    /**
     * This method deals a card without removing it from the deck.
     * @return returns the card that is to be dealt from the deck
     */
    public Card deal()
    {
        Card to_be_delt = this.contents.get(next_to_deal);
        next_to_deal++;
        return to_be_delt;
    }

    /**
     * It returns the card at a given position in the deck.
     */
    public Card cardAtAPosition()
    {
        return this.contents.get(next_to_deal);
    }

    /**
     * Returns the current size of the given deck.
     */
    public int size()
    {
        return CARDS_IN_A_DECK - next_to_deal;
    }

    /**
     * Gathers the pre-existing deck of cards to play again.
     */
    public void gather()
    {
        next_to_deal = 0;
    }

    /**
     * Checks if the deck is Empty.
     * @return true if empty else false.
     */
    public boolean isEmpty()
    {
        if (size() > 0)
            return false;
        else
            return true;
    }

    /**
     * Returns a human-readable string representation.
     */
    public String toString()
    {
        return this.contents.toString();
    }
}