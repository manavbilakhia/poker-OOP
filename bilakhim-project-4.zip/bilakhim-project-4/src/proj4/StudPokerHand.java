package proj4;

import java.util.ArrayList;

/**
 *  Represents a stud poker hand.
 */
public class StudPokerHand
{
    private ArrayList<Card> contents;
    private CommunityCardSet communitycards;

    /**
     * Parameterized constructor for class stud poker hand.
     * @param cc community cards.
     * @param cardList cards with player.
     */

    public StudPokerHand(CommunityCardSet cc, ArrayList<Card> cardList)
    {
        this.communitycards = cc;
        this.contents = cardList;
    }

    /**
     * Adds a single card to the player.
     * @param card the card to be added.
     */
    public void addCard(Card card)
    {
        if (this.contents.size() < 2)
        {
            this.contents.add(card);
        }
    }

    /**
     * Gets the ith card from the players cards.
     * @param i index of the card in the list.
     * @return The card.
     */
    public Card getIThCard(int i)
    {
        if (i>0 && i<2)
        {
            return this.contents.get(i);
        }
        return null;
    }

    /**
     * Compares two hands.
     * @param other the other hand.
     * @return 1 if this is greater than other. -1 if this is lesser than this.
     */
    public int compareTo(StudPokerHand other)
    {
        PokerHand hand1 = this.getBestFiveCardHand();
        PokerHand hand2 = other.getBestFiveCardHand();
        return hand1.compareTo(hand2);
    }

    /**
     * Get the best five card hand from a seven card arraylist.
     * @return The best 5 card hand combination.
     */
    private PokerHand getBestFiveCardHand() {
        ArrayList<PokerHand> hands = getAllFiveCardHands(5,getallsevencards());
        PokerHand bestSoFar = hands.get(0);
        for (int i = 1; i < hands.size(); i++) {
            if (hands.get(i).compareTo(bestSoFar) > 0) {
                bestSoFar = hands.get(i);
            }
        }
        return bestSoFar;
    }

    /**
     * Combines the community card set and cards with the player.
     * @return An arraylist of seven cards.
     */
    private ArrayList<Card> getallsevencards()
    {
        ArrayList<Card> list = new ArrayList<>();
        for (int i = 0; i < 5; i++)
        {
            list.add(this.communitycards.getIThCard(i));
        }
        for (int i = 0; i<2; i++)
        {
            list.add(this.contents.get(i));
        }
        return list;
    }

    /**
     * Gets all 5 card hand combinations.
     * @param targetSize the length of a poker hand.
     * @param list a list of all 7 cards.
     * @return a list of all 5 card hand combinations.
     */
    private ArrayList<PokerHand> getAllFiveCardHands(int targetSize, ArrayList<Card> list)
    {
        if (list.size() == targetSize)
        {
            return baseCase1ForGetAllFiveCardHandsMethod(list);
        }
        else if (targetSize == 1)
        {
            return baseCase2ForGetAllFiveCardHandsMethod(list);
        }
        Card firstcard = list.get(0);
        ArrayList<Card> rest = new ArrayList<>(list.subList(1, list.size()));
        ArrayList<PokerHand> combinationsWithoutFirst = getAllFiveCardHands(targetSize, rest);
        ArrayList<PokerHand> combinations = getAllFiveCardHands(targetSize-1, rest);
        ArrayList<PokerHand> combinationsWithFirst = addToAll(combinations, firstcard);
        ArrayList<PokerHand> allCombinations = addTwoLists(combinationsWithFirst, combinationsWithoutFirst);
        return allCombinations;
    }

    /**
     * Base case 1 for getAllFiveCardHands()
     */
    private ArrayList<PokerHand> baseCase1ForGetAllFiveCardHandsMethod(ArrayList<Card> list) {
        PokerHand hands = new PokerHand(list);
        ArrayList<PokerHand> handlist = new ArrayList<>();
        handlist.add(hands);
        return handlist;
    }

    /**
     * Base case 2 for getAllFiveCardHands()
     */
    private ArrayList<PokerHand> baseCase2ForGetAllFiveCardHandsMethod(ArrayList<Card> list) {
        ArrayList<PokerHand> handlist2 = new ArrayList<>();
        for (int i = 0; i < list.size(); i++)
        {
            PokerHand toAdd = new PokerHand();
            toAdd.addCard(list.get(i));
            handlist2.add(toAdd);
        }
        return handlist2;
    }

    /**
     * Adds any given 2 arraylists.
     * @param list1 arraylists to be added.
     * @param list2 arraylists to be added.
     * @return the combined arraylists.
     */
    private ArrayList<PokerHand> addTwoLists (ArrayList<PokerHand> list1, ArrayList<PokerHand> list2)
    {
        ArrayList<PokerHand> combinedList= new ArrayList<>();
        combinedList.addAll(list2);
        combinedList.addAll(list1);
        return combinedList;
    }

    /**
     * Makes the final combinations by adding 1 card to every combination in the arraylist
     * @param combinations the arraylist with incomplete combinations.
     * @param toAdd the card to add to each combination.
     * @return an arraylist with all complete combinations.
     */
    private ArrayList<PokerHand> addToAll (ArrayList<PokerHand> combinations, Card toAdd)
    {
        for (PokerHand hand : combinations)
        {
            hand.addCard(toAdd);
        }
        return combinations;
    }
    /**
     * Returns a human readable string representation of a hand.
     */
    public String toString()
    {
        return getBestFiveCardHand().toString();
    }
}