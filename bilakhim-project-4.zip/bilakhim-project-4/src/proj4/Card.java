package proj4; // do not erase. Gradescope expects this.

/**
 * This class represents a standard playing card and has functions relating to comparison of 2 cards based on their ranks
 * and their suits
 */

public class Card {
    private int rank;
    private final String suit;

    /**
     * Creates a Card with a given rank and suit.
     *
     * @param ranks The rank of the card, which must be between
     *              2 and 14, inclusive.
     * @param suit The suit of the card, which must be
     *              0=SPADES, 1=HEARTS, 2=CLUBS, or 3=DIAMONDS
     */

    public Card(int ranks, int suit) {
        String[] SUITS = new String[]{"SPADES", "HEARTS", "CLUBS", "DIAMONDS"};
        if (ranks < 15 || ranks > 1)
        {
            this.rank = ranks;
        }
        this.suit = SUITS[suit];

    }
    /**
     * Creates a Card with a given rank and suit.
     *
     * @param ranks whole cards (2-10) can either be spelled
     *              out like "two" or numeric like "2". Case
     *              insensitive.
     * @param suit "Spades", "Hearts", "Clubs", or "Diamonds"
     */
    public Card(String ranks, String suit)
    {
        String [] RANKS1 = new String[] {"Two","Three","Four","Five","Six","Seven","Eight","Nine","Ten","Jack","Queen",
                "King","Ace"};
        String [] RANKS2 = new String [] {"2","3","4","5","6","7","8","9","10","Jack", "Queen", "King", "Ace"};
        String [] RANKS3 = new String[] {"two","three","four","five","six","seven","eight","nine","ten","jack","queen",
                "king","ace"};

        for (int i = 0; i < RANKS1.length; i++)
        {
            if (RANKS1[i].equals(ranks))
            {
                this.rank = java.util.Arrays.asList(RANKS1).indexOf(ranks) + 2;
            }
            else if(RANKS3[i].equals(ranks))
            {
                this.rank = java.util.Arrays.asList(RANKS3).indexOf(ranks) + 2;
            }
            else if (RANKS2[i].equals(ranks))
            {
                this.rank = java.util.Arrays.asList(RANKS2).indexOf(ranks) + 2;
            }
        }
        this.suit = suit;
    }
    /**
     * Gets the rank of a card.
     * @return An integer value rank.
     */
    public int getRank()
    {
        return this.rank;
    }
    /**
     * Gets the suit of a card.
     * @return An string value suit.
     */
    public String getSuit()
    {
        return this.suit;
    }

    /**
     * Checks whether this and other have the same suit (case insensetive).
     * @param other The other card.
     * @return A boolean value, true if they have the same suit, else false.
     */
    public boolean equalsSuit (Card other)
    {
        String t1 = this.suit;
        String t2 = other.suit;
        return t1.equalsIgnoreCase(t2);
    }
    /**
     * Checks whether this has a lesser rank than the other.
     * @param other The other card.
     * @return A boolean value, true if this has a lesser rank, else false.
     */
    public boolean lesserThanRank(Card other)
    {
        int t1 = this.rank;
        int t2 = other.rank;
        return t1 < t2;
    }
    /**
     * Checks whether this has a greater rank than the other.
     * @param other The other card.
     * @return A boolean value. true if this has a greater rank, else false.
     */
    public boolean greaterThanRank(Card other)
    {
        int t1 = this.rank;
        int t2 = other.rank;
        return t1 > t2;
    }
    /**
     * Checks whether this and other have the same rank.
     * @param other The other card.
     * @return A boolean value, true if they have the same rank, else false.
     */
    public boolean equalsRank(Card other)
    {
        int t1 = this.rank;
        int t2 = other.rank;
        return t1 == t2;
    }
    /**
     * Returns a human readable string representation of a card with string values for the ranks.
     */
    public String toString()
    {
        String[] RANKS = {"Jack","Queen","King","Ace"};
        if (this.rank > 10)
            return RANKS[this.getRank()-11] + " of " + this.getSuit();
        else
            return this.getRank() + " of " + this.getSuit();
    }
}