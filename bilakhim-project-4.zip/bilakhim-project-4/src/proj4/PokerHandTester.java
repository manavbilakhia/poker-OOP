package proj4;

/**
 * Testing module for class PokerHand.
 */
public class PokerHandTester
{
    /**
     * Main calls methods which have the tests.
     */
    public static void main(String[] args)
    {
        Testing t = new Testing();
        t.startTests();
        t.testSection("Class PokerHand");
        testMethodsOfClassPokerHand(t);
        t.finishTests();
    }
    /**
     * Testing methods of class PokerHand.
     * @param t Testing parameter.
     */
    public static void testMethodsOfClassPokerHand(Testing t)
    {
        Card c3 = new Card("Three","Clubs");
        Card c5 = new Card("Five","Clubs");
        Card c6 = new Card("Six","Clubs");
        Card c7 = new Card("Seven","Clubs");
        Card c8 = new Card("Eight","Clubs");
        Card c9 = new Card("Nine","Clubs");
        Card c10 = new Card("Jack", "Clubs");
        Card c13 = new Card("King", "Clubs");
        Card c14 = new Card("Ace","Clubs");
        Card h2 = new Card("Two","Hearts");
        Card h3 = new Card("Three","Hearts");
        Card h4 = new Card("Four","Hearts");
        Card h5 = new Card("Five","Hearts");
        Card h6 = new Card("Six","Hearts");
        Card h7 = new Card("Seven","Hearts");
        Card h8 = new Card("Eight","Hearts");
        Card h10 = new Card("Ten","Hearts");
        Card h12 = new Card("Queen","Hearts");
        Card h13 = new Card("King","Hearts");
        Card h14 = new Card("Ace","Hearts");
        Card s4 = new Card("Four", "Spades");
        Card s5 = new Card("Five", "Spades");
        Card s9 = new Card("Nine", "Spades");
        Card s10 = new Card("Ten", "Spades");
        Card s11 = new Card("Jack", "Spades");
        Card s12 = new Card("Queen", "Spades");
        Card s13 = new Card("King", "Spades");
        Card s14 = new Card("Ace", "Spades");
        Card d2 = new Card("Two","Diamonds");
        Card d3 = new Card("Three","Diamonds");
        Card d4 = new Card("Four","Diamonds");
        Card d5 = new Card("Five","Diamonds");
        Card d6 = new Card("Six","Diamonds");
        Card d8 = new Card("Eight","Diamonds");
        Card d9 = new Card("Nine", "Diamonds");
        Card d10 = new Card("Ten", "Diamonds");
        Card d11 = new Card("Jack", "Diamonds");
        Card d12 = new Card("Queen","Diamonds");
        Card d13 = new Card("King", "Diamonds");
        Card d14 = new Card("Ace", "Diamonds");

        PokerHand hand1 = new PokerHand();
        hand1.addCard(d14);
        hand1.addCard(d9);
        hand1.addCard(d13);
        hand1.addCard(d2);
        hand1.addCard(d12);
        PokerHand hand2 = new PokerHand();
        hand2.addCard(d3);
        hand2.addCard(d11);
        hand2.addCard(d4);
        hand2.addCard(d10);
        hand2.addCard(d5);
        PokerHand hand3 = new PokerHand();
        hand3.addCard(d6);
        hand3.addCard(c6);
        hand3.addCard(c13);
        hand3.addCard(d13);
        hand3.addCard(d5);
        PokerHand hand4 = new PokerHand();
        hand4.addCard(s14);
        hand4.addCard(c14);
        hand4.addCard(h6);
        hand4.addCard(h7);
        hand4.addCard(c7);
        PokerHand hand5 = new PokerHand();
        hand5.addCard(c10);
        hand5.addCard(h13);
        hand5.addCard(c6);
        hand5.addCard(d8);
        hand5.addCard(c8);
        PokerHand hand6 = new PokerHand();
        hand6.addCard(c9);
        hand6.addCard(d9);
        hand6.addCard(h4);
        hand6.addCard(h8);
        hand6.addCard(c14);
        PokerHand hand7 = new PokerHand();
        hand7.addCard(d13);
        hand7.addCard(s4);
        hand7.addCard(d6);
        hand7.addCard(h7);
        hand7.addCard(s10);
        PokerHand hand8 = new PokerHand();
        hand8.addCard(h10);
        hand8.addCard(d2);
        hand8.addCard(h12);
        hand8.addCard(d4);
        hand8.addCard(s5);
        PokerHand hand9 = new PokerHand();
        hand9.addCard(d10);
        hand9.addCard(h2);
        hand9.addCard(d12);
        hand9.addCard(h4);
        hand9.addCard(c5);
        PokerHand hand10 = new PokerHand();
        hand10.addCard(h5);
        hand10.addCard(c7);
        hand10.addCard(d12);
        hand10.addCard(s12);
        hand10.addCard(s9);
        PokerHand hand11 = new PokerHand();
        hand11.addCard(h3);
        hand11.addCard(d11);
        hand11.addCard(c10);
        hand11.addCard(h13);
        hand11.addCard(s11);
        PokerHand hand12 = new PokerHand();
        hand12.addCard(c10);
        hand12.addCard(h13);
        hand12.addCard(c6);
        hand12.addCard(d8);
        hand12.addCard(c8);
        PokerHand hand13 = new PokerHand();
        hand13.addCard(c3);
        hand13.addCard(d3);
        hand13.addCard(h4);
        hand13.addCard(h8);
        hand13.addCard(c14);
        PokerHand hand14 = new PokerHand();
        hand14.addCard(s12);
        hand14.addCard(c3);
        hand14.addCard(h12);
        hand14.addCard(s13);
        hand14.addCard(h10);
        PokerHand hand15 = new PokerHand();
        hand15.addCard(s4);
        hand15.addCard(h8);
        hand15.addCard(c8);
        hand15.addCard(h2);
        hand15.addCard(h14);

        t.assertEquals("testing when both hands are flush (hand 1 and hand 2)",
                1, hand1.compareTo(hand2));              //1
        t.assertEquals("testing when one hand is a flush other is not (hand 1 and hand 8)",
                1, hand1.compareTo(hand8));              //2
        t.assertEquals("testing when one hand is a flush other is a 2 pair (hand 1 and hand 4)",
                1, hand1.compareTo(hand4));            //3
        t.assertEquals("testing when one hand is a flush other is a pair (hand 1 and hand 13)",
                1, hand1.compareTo(hand13));                  //4
        t.assertEquals("testing when both hands are 2 pairs (hand 3 and hand 4)",
                -1, hand3.compareTo(hand4));                //5
        t.assertEquals("testing when one hand is a 2pair other is not (hand 3 and hand 7)",
                1, hand3.compareTo(hand7));                   //6
        t.assertEquals("testing when both hands are pairs (hand 5 and hand 6)",
                -1, hand5.compareTo(hand6));                 //7
        t.assertEquals("testing when one hand is a pair and other is a 2pair (hand 5 and hand 3)",
                -1, hand5.compareTo(hand3));                   //8
        t.assertEquals("testing when both hands are highcards (hand 7 and hand 8)",
                1, hand7.compareTo(hand8));                   //9
        t.assertEquals("testing when both hands are a tie (hand 8 and hand 9)",
                0, hand8.compareTo(hand9));                         //10
        t.assertEquals("testing when both hands are a pairs. Has a pair of queen and other has highcard of king (hand 10 and hand 11)",
                1, hand10.compareTo(hand11));                           //11
        t.assertEquals("testing when both hands are a pairs this has double of 8 other has highcard ace (hand 12 and hand 13)",
                1, hand12.compareTo(hand13));                               //12
        t.assertEquals("testing when both hands are a pairs this has pair of 8, other has pair of 4.(hand 14 and hand 15)",
                1, hand14.compareTo(hand15));
    }
}
