package proj4;

/**
 * Testing module for class CommunityCardSet.
 */
public class CommunityCardSetTester
{
    /**
     * Main calls methods which have the tests.
     */
    public static void main(String[] args) {
        Testing t = new Testing();
        t.startTests();
        t.testSection("Class CommunityCardSet");
        testMethodsOfClassCommunityCardSet(t);
        t.finishTests();
    }

    /**
     * Testing methods of class CommunityCardSet.
     * @param t Testing parameter.
     */
    public static void testMethodsOfClassCommunityCardSet(Testing t) {
        Card d2 = new Card("Two", "Diamonds");
        Card d3 = new Card("Three", "Diamonds");
        Card d4 = new Card("Four", "Diamonds");
        Card d5 = new Card("Five", "Diamonds");
        Card d9 = new Card("Nine", "Diamonds");
        Card d10 = new Card("Ten", "Diamonds");
        Card d11 = new Card("Jack", "Diamonds");
        Card d12 = new Card("Queen", "Diamonds");
        Card d13 = new Card("King", "Diamonds");
        Card d14 = new Card("Ace", "Diamonds");

        CommunityCardSet set1 = new CommunityCardSet();
        set1.addCard(d14);
        set1.addCard(d9);
        set1.addCard(d13);
        set1.addCard(d2);
        set1.addCard(d12);
        CommunityCardSet set2 = new CommunityCardSet();
        set2.addCard(d3);
        set2.addCard(d11);
        set2.addCard(d4);
        set2.addCard(d10);
        set2.addCard(d5);

        t.assertEquals("Getting the first card of the community card set",
                        d14, set1.getIThCard(0));
        t.assertEquals("Getting the last card of the community card set",
                d5, set2.getIThCard(4));

    }
}
