package proj4;

import java.util.ArrayList;

/**
 * This class represents a community card set.
 */
public class CommunityCardSet
{

    private final static int CARDS_IN_A_COMMUNITY_HAND = 5;
    private ArrayList<Card> contents = new ArrayList<>();

    /**
     * Default constructor for class Community card set.
     */
    public CommunityCardSet()
    {
        this.contents = new ArrayList<>();
    }

    /**
     * Parameterized constructor for class community card set.
     * @param cardList the list of cards that have to be added to the set.
     */
    public CommunityCardSet(ArrayList<Card> cardList)
    {
        {
            for (Card card: cardList)
            {
                this.contents.add(card);
            }
        }
    }

    /**
     * Adds a single card to the set
     * @param card the card to be added
     */
    public void addCard(Card card)
    {
        if (this.contents.size() < 5)
        {
            this.contents.add(card);
        }
    }
    
    /**
     * Gets the card at a particular index from the set.
     * @param i Index.
     * @return A card.
     */
    public Card getIThCard(int i)
    {
        if (i>-1 && i<CARDS_IN_A_COMMUNITY_HAND)
        {
            return this.contents.get(i);
        }
        return null;
    }
    /**
     * Returns a human-readable string representation.
     */
    public String toString()
    {
        return this.contents.toString();
    }
}