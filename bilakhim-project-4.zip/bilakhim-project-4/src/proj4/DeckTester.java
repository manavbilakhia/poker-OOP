package proj4;

/**
 * Testing for class deck
 */
public class DeckTester
{
    /**
     * Main calls methods which have the tests.
     */
    public static void main(String[] args) {
        Deck deck = new Deck();
        deck.shuffle();
        Testing t = new Testing();
        t.startTests();
        t.testSection("Class Deck");
        testMethodsOfClassDeck(t);
        t.finishTests();
    }
    /**
     * Testing methods of class Deck.
     * @param t testing parameter.
     */
    public static void testMethodsOfClassDeck(Testing t)
    {
        Deck deck = new Deck();
        t.assertEquals("checking the size of the deck", 52, deck.size());
        deck.shuffle();
        System.out.println(deck);
        t.assertEquals("dealing cards", deck.cardAtAPosition(), deck.deal());
        deck.deal();
        deck.deal();
        deck.deal();
        deck.shuffle();
        System.out.println(deck);
        t.assertEquals("checking the size of the deck", 48, deck.size());
        for (int i = 0; i < 48; i++)
        {
            deck.deal();
        }
        t.assertEquals("check if the deck is empty after dealing all cards", true, deck.isEmpty());
        deck.gather();
        t.assertEquals("check the size of the deck", 52, deck.size());
    }
}