package proj4;

/**
 * Testing module for class Card.
 */
public class CardTester
{
    /**
     * Main calls methods which have the tests.
     */
    public static void main(String[] args) {
        Testing t = new Testing();
        t.startTests();
        t.testSection("Class Card");
        testMethodsOfClassCard(t);
        t.finishTests();
    }

    /**
     * Testing methods of class card.
     * @param t testing parameter.
     */
    public static void testMethodsOfClassCard(Testing t)
    {
        Card c1 = new Card("Five","Clubs");
        Card c2 = new Card("Six", "Spades");
        Card c3 = new Card(10, 2);
        Card c4 = new Card("five", "Spades");
        Card c5 = new Card ("Ten","Clubs");
        Card c6 = new Card ("ten", "Clubs");
        t.assertEquals("checking if cards have the same suit", true, c1.equalsSuit(c3));
        t.assertEquals("checking if the cards have the same rank", true, c1.equalsRank(c4));
        t.assertEquals("card one has a higher rank than card 2", true, c2.greaterThanRank(c1));
        t.assertEquals("card one has a lower rank than card 2", true, c1.lesserThanRank(c2));
        t.assertEquals("get the rank of the card", 5, c1.getRank());
        t.assertEquals("get the suit of the card", "Spades", c2.getSuit());
        System.out.println(c3);
        System.out.println(c5);
        System.out.println(c6);
        System.out.println(c4);
    }
}