import java.util.ArrayList;

public class ListProcessor
{
    /**
     * Swaps elements i and j in the given list.
     */
    private void swap(ArrayList<String> aList, int i, int j)
    {
        String tmp = aList.get(i);
        aList.set(i, aList.get(j));
        aList.set(j, tmp);
    }

    /**
     * Finds the minimum element of a list, returns it.
     *
     * @param aList the list in which to find the minimum element.
     * @return the minimum element of the list.
     */
    public String getMin(ArrayList<String> aList)
    {
          if(aList.size() == 1)
          {
              return aList.get(0);
          }
          String first = aList.get(0);
          ArrayList<String> rest = new ArrayList<>(aList.subList(1, aList.size()));
          String minInRest = getMin(rest);
          if (first.compareTo(minInRest) <= 0)
          {
              return first;
          }
          else
          {
              return minInRest;
          }

//        String minElement = aList.get(0);
//        for (int i = 1; i < aList.size(); i++) {
//            if (aList.get(i).compareTo(minElement) < 0) {
//                minElement = aList.get(i);
//            }
//        }
//        return minElement;
    }


    /**
     * Finds the minimum element of a list, returns the index of that
     * element.
     *
     * @param aList the list in which to find the minimum element.
     * @return the index of the minimum element in the list.
     */
    public int getMinIndex(ArrayList<String> aList)
    {
        if(aList.size() == 1)
        {
            return 0;
        }
        String first = aList.get(0);
        ArrayList<String> rest = new ArrayList<>(aList.subList(1, aList.size()));
        int minPosInRest = getMinIndex(rest) + 1;
        if(first.compareTo(aList.get(minPosInRest)) <= 0)
        {
            return 0;
        }
        else
        {
            return minPosInRest;
        }
//        int minIndex = 0;
//        for (int i = 1; i < aList.size(); i++) {
//            if (aList.get(i).compareTo(aList.get(minIndex)) < 0) {
//                minIndex = i;
//            }
//        }
//        return minIndex;
    }

    
    /**
     * Sorts a list in place. I.E. the list is modified so that it is in order.
     *
     * @param aList: the list to sort.
     */
    public void sort(ArrayList<String> aList)
    {
        sortSublist(aList,0);
    }
    /**
     * Sorts the portion of 'aList' from index 'start' to the end of
     * 'aList'. The list is sorted in place.
     *
     * @param aList the list to sort
     * @param start the index of the first element of interest.
     */
    private void sortSublist(ArrayList<String> aList, int start)
    {

        if (start >= aList.size()) {
            return;
        }
        ArrayList<String>rest = new ArrayList<>(aList.subList(start, aList.size()));
        int minIndexInAList = getMinIndex(rest)+start;
        swap(aList, start, minIndexInAList);
        sortSublist(aList,start + 1);
    }
}
    

