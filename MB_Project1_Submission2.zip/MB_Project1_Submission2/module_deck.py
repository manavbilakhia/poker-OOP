# I affirm that I have carried out my academic endeavors with full academic honesty.
# @MB (Manav Bilakhia)

# imports
import random
import module_card
import module_hand


# ----------------------------------------------------------------------------------------------------------------------


def create_deck():
    """
    Creates a new deck.

    :return: A list of cards in a deck.
    """
    suits_in_a_deck = ["♥", "♣", "♠", "♦"]
    ranks_in_a_suit = ['1', '2', '3', '4', '5', '6', '7', '8', '9', 'T', 'J', 'Q', 'K']
    deck = []
    for suit in suits_in_a_deck:
        for rank in ranks_in_a_suit:
            card = module_card.create_card(rank, suit)
            deck.append(card)
#    print(deck)
#    Shuffle_deck(deck)
    module_hand.dealing(deck)
    return deck


# ----------------------------------------------------------------------------------------------------------------------


def shuffle_deck(deck):
    """
    Shuffles a given deck.

    :param deck: Takes a list of cards in a deck.
    :return: A shuffled deck.
    """
    random.shuffle(deck)
#   print(deck)
    return deck


# ----------------------------------------------------------------------------------------------------------------------


def update_deck(hand, deck):
    """
     Updates the deck after a hand is dealt.

    :param hand: A list of cards in a hand.
    :param deck: Takes a list of cards in a deck.
    :return: A list of cards in he deck minus the list of cards in the hand.
    """
    set1 = set(deck)
    set2 = set(hand)
    updated_deck = list(set1 - set2)
#    print(deck)
    return updated_deck


# ----------------------------------------------------------------------------------------------------------------------


if __name__ == '__main__':
    create_deck()
