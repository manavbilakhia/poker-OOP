# I affirm that I have carried out my academic endeavors with full academic honesty.
# @MB (Manav Bilakhia)

# imports
import module_card

CARDS_IN_A_HAND = 5
# ----------------------------------------------------------------------------------------------------------------------


def check_flush(hand):
    """
    Checks if the given hand is a flush.

    :param hand: A list of cards in a hand.
    :return: False if suit of all cards in a hand are not equal. If not, returns True.
    """
    hand_suit = module_card.get_suit(hand[0])
#    flag = True
    for card in hand:
        if hand_suit != module_card.get_suit(card):
            return False
#    print(flag)
    return True


# ----------------------------------------------------------------------------------------------------------------------


def count_pair(hand):
    """
    Counts the number of pairs in a given hand.

    :param hand: A list of cards in a hand.
    :return: Integer of number of pairs in a given hand.
    """
    hand.sort()
    no_of_pairs = 0
    i = 0
    while i < CARDS_IN_A_HAND-1:
        card1 = hand[i]
        card2 = hand[i + 1]
        if module_card.compare_rank(card1, card2):
            no_of_pairs = no_of_pairs + 1
            i = i + 2
        else:
            i = i + 1
    return no_of_pairs

# ----------------------------------------------------------------------------------------------------------------------
