# I affirm that I have carried out my academic endeavors with full academic honesty.
# @MB (Manav Bilakhia)

# imports
import module_deck

# ----------------------------------------------------------------------------------------------------------------------
CARDS_IN_A_HAND = 5


def create_hand(deck):
    """
    Creates a hand form a given deck.

    :param deck: Takes a list of cards in a deck.
    :return: A list of cards in a hand.
    """
    hand = []
    for i in range(CARDS_IN_A_HAND):
        hand.append(deck[i])

#    print(hand)
    return hand


# ----------------------------------------------------------------------------------------------------------------------


def dealing(deck):
    """
    Simulates the dealing of a hand.

    :param deck: Takes a list of cards in a deck.
    :return: A list of cards in a hand.
    """
    if len(deck) > CARDS_IN_A_HAND:
        hand = create_hand(deck)
        deck = module_deck.update_deck(hand, deck)
#        print(hand)
#        print(deck)
    else:
        deck = deck.create_deck()
        module_deck.shuffle_deck(deck)
        hand = create_hand(deck)
        deck = module_deck.update_deck(hand, deck)
#        print(hand)
#        print(deck)
    return hand

# ----------------------------------------------------------------------------------------------------------------------
