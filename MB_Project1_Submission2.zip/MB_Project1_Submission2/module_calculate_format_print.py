# I affirm that I have carried out my academic endeavors with full academic honesty.
# @MB (Manav Bilakhia)


def calculate_and_modify(hands_dealt, hand_type_counter):
    """
    Calculates the percentage and modifies the numbers as per desired output.

    :param hands_dealt: Takes the integer for the number of hands.
    :param hand_type_counter:  Takes the integer number of times a particular type of hand is found.
    :return: A float of modified percentage.
    """
    percentage = (float(hand_type_counter) / hands_dealt) * 100
    modify_percentage = "{:05.2f}".format(percentage)
    return modify_percentage


# ----------------------------------------------------------------------------------------------------------------------


def print_values(hands_dealt, pairs, double_pairs, flush, high_cards):
    """
    Prints the main tables as per desired output.

    :param hands_dealt: Takes the integer for the number of hands.
    :param pairs: Takes the integer number of pair occurrence  in a given number of dealt hands.
    :param double_pairs: Takes the integer number of pair occurrences in a given number of dealt hands.
    :param flush: Takes the integer number of flush occurrences in a given number of dealt hands.
    :param high_cards: Takes the integer number of high card occurrences in a given number of dealt hands.
    """
    percent_flush = calculate_and_modify(hands_dealt, flush)
    percent_pairs = calculate_and_modify(hands_dealt, pairs)
    percent_double_pairs = calculate_and_modify(hands_dealt, double_pairs)
    percent_high_cards = calculate_and_modify(hands_dealt, high_cards)

    print("%10s %10d %4s %12d %4s %12d %4s %14d %4s" %
          ("{:,}".format(hands_dealt), pairs, percent_pairs, double_pairs, percent_double_pairs, flush, percent_flush,
           high_cards, percent_high_cards))

# ----------------------------------------------------------------------------------------------------------------------
