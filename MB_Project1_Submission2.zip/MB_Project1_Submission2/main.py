# I affirm that I have carried out my academic endeavors with full academic honesty.
# @MB (Manav Bilakhia)

# imports
import module_deck
import module_hand
import module_check_hand
import module_calculate_format_print


# ----------------------------------------------------------------------------------------------------------------------


def the_game(hands_dealt):
    """
    This function simulates the game.

    :param hands_dealt: Takes the integer for the number of hands
    :return: The integer for the number of hands, integer for number of times a flush occurs, integer for number of
    times a double pair occurs, integer for number of times a pair occurs, integer for number of times a high card
    occurs.
    """
    deck = module_deck.create_deck()
    flush = 0
    double_pairs = 0
    pairs = 0
    high_cards = 0
    for j in range(hands_dealt):
        deck = module_deck.shuffle_deck(deck)
        current_hand = module_hand.dealing(deck)
#        print(current_hand)
        if module_check_hand.check_flush(current_hand):
            flush = flush + 1
        elif module_check_hand.count_pair(current_hand) == 2:
            double_pairs = double_pairs + 1
        elif module_check_hand.count_pair(current_hand) == 1:
            pairs = pairs + 1
        else:
            high_cards = high_cards + 1
    module_calculate_format_print.print_values(hands_dealt, pairs, double_pairs, flush, high_cards)
    return hands_dealt, flush, double_pairs, pairs, high_cards


# ----------------------------------------------------------------------------------------------------------------------


def run():
    """
    This function determines the number of times hands are to be dealt.

    """
    print("{:15} {:<7} {:<8} {:<9} {:<8} {:<9} {:<8} {:<11} {:<10}"
          .format('# of hands', 'pairs', '%', '2 pairs', '%', 'flushes', '%', 'high card', '%'))
    RECORD_DATA = 10
    for i in range(RECORD_DATA):
        i = 10000 + (i * 10000)
        the_game(i)


# ----------------------------------------------------------------------------------------------------------------------


if __name__ == '__main__':
    run()
