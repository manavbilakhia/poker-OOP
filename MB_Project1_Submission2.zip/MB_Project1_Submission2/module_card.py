# I affirm that I have carried out my academic endeavors with full academic honesty.
# @MB (Manav Bilakhia)


def create_card(rank, suit):
    """
    Creates a card with given rank and suit, returns it.

    :param rank: Takes a string rank for a card.
    :param suit: Takes a string suit for a card.
    :return: The created card.
    """
    card = str(rank) + " of " + str(suit)
#    print(card)
#    Get_suit(card)
#    Get_rank(card)
    return card


# ----------------------------------------------------------------------------------------------------------------------


def get_rank(card):
    """
    Returns the rank of a given card.

    :param card: The card to inspect.
    :return: The rank of the card.
    """
#    print(card[0])
    return card[0]


# ----------------------------------------------------------------------------------------------------------------------


def compare_rank(card1, card2):
    """
    Compares the rank of two cards.

    :param card1: The first card to inspect.
    :param card2: The second card to inspect.
    :return: True if the ranks of two cards are equal, if not returns False.
    """
    return get_rank(card1) == get_rank(card2)


# ----------------------------------------------------------------------------------------------------------------------


def get_suit(card):
    """
     Returns the suit of a given card.

     :param card: The card to inspect.
     :return: The suit of the card.
     """
    return card[-1]


# ----------------------------------------------------------------------------------------------------------------------

if __name__ == '__main__':
    card1 = create_card('3', '♥')
    card2 = create_card('4', '♦')
    get_rank(card1)
    compare_rank(card1, card2)
