# I affirm that I have carried out my academic endeavors with full academic honesty.
# @MB (Manav Bilakhia)

# importing  scripts from this project
import Check_rows_columns_diagonals
# ----------------------------------------------------------------------------------------------------------------------

# function to check number of column. if number of column is exactly 3, it will check for three in a column and diagonal
def check_no_of_columns(board):
    rows = board.split('\n')
#    column = []

#    for i in range(len(rows)):
#        column.append(rows[0][i])
#    print(column)
#    print(len(rows[0]))
    if ((len(rows[0]) !=3) or (len(rows[1]) !=3) or (len(rows[2]) != 3)):
        print('The number of columns is not exactly 3')
    else:
        print('The number of columns is exactly 3')
        Check_rows_columns_diagonals.horizontal_check(rows)  # function call to check for three in a row
        Check_rows_columns_diagonals.vertical_check(rows)  # function call to check for three in a column
        Check_rows_columns_diagonals.diagonal_check(rows)  # function call to check for three in a diagonal
# ----------------------------------------------------------------------------------------------------------------------
