# I affirm that I have carried out my academic endeavors with full academic honesty.
# @MB (Manav Bilakhia)

# importing  scripts from this project
import Check_rows_columns_diagonals
import Checking_no_of_columns
# ---------------------------------------------------------------------------------------------------------------------


# function to check number of rows. if number of rows is exactly 3, it will check for three in a row
def check_no_of_rows(board):
    rows = board.split('\n')

    if len(rows) != 3:  # desired number of rows is 3. len has been used as each row is an element in the list 'rows'
        print("The number of rows is not exactly 3. Please change the input. Make sure you have not pressed enter after typing in row 3")
    else:
        print('The number of rows is exactly 3')
        Checking_no_of_columns.check_no_of_columns(board)  # columns
#        Check_rows_columns_diagonals.horizontal_check(rows)  # function call to check for three in a row
# ----------------------------------------------------------------------------------------------------------------------
