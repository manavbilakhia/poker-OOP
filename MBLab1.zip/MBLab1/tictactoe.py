# I affirm that I have carried out my academic endeavors with full academic honesty.
# @MB (Manav Bilakhia)

# importing scripts from this project
import Checking_no_of_rows
# ----------------------------------------------------------------------------------------------------------------------

# opening and reading the text file
boardfile = open("tictactoe_board.txt")
board = boardfile.read()
boardfile.close()
# ----------------------------------------------------------------------------------------------------------------------

# function call from other scripts to check the number of rows
Checking_no_of_rows.check_no_of_rows(board)  # rows
# ----------------------------------------------------------------------------------------------------------------------
