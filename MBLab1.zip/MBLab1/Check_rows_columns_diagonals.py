# I affirm that I have carried out my academic endeavors with full academic honesty.
# @MB (Manav Bilakhia)

# function for checking 3 in a row
def horizontal_check(rows):
    for i in range(len(rows)):
        if rows[i][0] == rows[i][1] == rows[i][2]:
            print('Three in a row in row ' + str(i + 1))
            print("We have a Winner!!!")
# ----------------------------------------------------------------------------------------------------------------------

# function for checking 3 in a column
def vertical_check(rows):
    for i in range(len(rows)):
        if rows[0][i] == rows[1][i] == rows[2][i]:
            print('Three in a column in column ' + str(i + 1))
            print("We have a Winner!!!")
# ----------------------------------------------------------------------------------------------------------------------

# function for checking diagonal
def diagonal_check(rows):
    if ((rows [0][0] == rows [1][1] == rows[2][2]) or (rows[0][2] == rows[1][1] == rows[2][0])):
        print("Diagonal exists")
        print("We have a Winner!!!")
# ----------------------------------------------------------------------------------------------------------------------
